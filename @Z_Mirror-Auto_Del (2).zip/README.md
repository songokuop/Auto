# Z Auto-Delete
 A bot which can delete older messages from groups.
